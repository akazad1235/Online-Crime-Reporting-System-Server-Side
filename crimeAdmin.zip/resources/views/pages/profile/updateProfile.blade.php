@extends('layouts.master')
@section('content')
<div class="row">
            <div class="col-sm-12">
              
            </div> 
        </div>

@endsection