
<?php $__env->startSection('content'); ?>
<div class="row">
            <div class="col-sm-12">
                <div class="card-box">
                    <h4 class="header-title font-weight-bold">All Police Station</h4>
                    
                        <?php if(Session::has('added_recorded')): ?>
                            <script>
                                toastr.success("<?php echo Session::get('added_recorded'); ?>");
                            </script>
                        <?php endif; ?>
                         <?php if(Session::has('error_recorded')): ?>
                            <script>
                                toastr.error("<?php echo Session::get('error_recorded'); ?>");
                            </script>
                        <?php endif; ?>

                    <button id="demo-delete-row" class="btn btn-danger btn-sm" disabled><i class="mdi mdi-close mr-1"></i>Delete</button>
                    <table id="demo-custom-toolbar"  data-toggle="table"
                            data-toolbar="#demo-delete-row"
                            data-search="true"
                            data-show-refresh="true"
                            data-show-columns="true"
                            data-sort-name="id"
                            data-page-list="[5, 10, 20]"
                            data-page-size="5"
                            data-pagination="true" data-show-pagination-switch="true" class="table-borderless">
                        <thead class="thead-light">
                        <tr>
                            <th data-field="state" data-checkbox="true"></th>
                            <th data-field="id" data-sortable="true" >Station</th>
                            <th data-field="name" data-sortable="true">Name</th>
                            <th data-field="email" data-sortable="true">Email</th>
                            <th data-field="uesr_rules" data-sortable="true" data-formatter="dateFormatter">User Rules</th>
                            <th data-field="status" data-sortable="true" data-formatter="dateFormatter">Status</th>
                            <th data-field="action" data-sortable="true">Action</th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php $__currentLoopData = $allUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tr>
                            <td></td>
                            <td><?php echo e($value->station); ?></td>
                            <td><?php echo e($value->name); ?></td>
                            <td><?php echo e($value->email); ?></td>
                            <td><?php echo e($value->is_admin == 1? 'Admin' : 'User'); ?></td>
                            <td><span class="badge  badge-<?php echo e(($value->status == 1 ? 'success' : 'danger' )); ?> text-capitalize"><?php echo e($value->status ==1 ? 'Active':'Inactive'); ?></span></td>
                            <td><a class="btn btn-info btn-sm" href="<?php echo e(route('station.edit', base64_encode($value->id))); ?>">Edit</a> <a class="btn btn-danger btn-sm" href="<?php echo e(route('station.delete', base64_encode($value->id))); ?>">Delete</a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div> <!-- end card-box-->
            </div> <!-- end col-->
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crimeAdmin\resources\views/pages/users/manageUser.blade.php ENDPATH**/ ?>