
<?php $__env->startSection('content'); ?>
<div class="row">
            <div class="col-sm-12">
                <div class="row">
                    <?php $__currentLoopData = $profileData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <h3 class="text-center">Profile</h3>
                        <div class="text-center">
                            <img  src="<?php echo e(asset('admin/images/users/user-2.jpg')); ?>" alt="">
                            
                           
                            <div class="checkbox checkbox-success mb-2 mt-3">
                                <input id="checkbox3" type="checkbox" checked >
                                <label for="checkbox3" class='text-secondary font-weight-bold'>
                                    <?php echo e($value->designation); ?>

                                </label>
                            </div>
                            
                        </div>
                        <a href="<?php echo e(route('profile.edit')); ?>" type="button" class="btn btn-danger form-control p-2 my-3 font-weight-bold">Edit Profile</a>
                        
                        
                    </div>
                    <div class="col-md-8">
                      <div class="row my-1  border-bottom">
                          <div class="col-md-3 font-weight-bold">Name</div>
                          <div class="col-md-8"><?php echo e($value->name); ?></div>
                      </div>
                      <div class="row my-1 border-bottom">
                        <div class="col-md-3 font-weight-bold">Email</div>
                        <div class="col-md-8"><?php echo e($value->email); ?></div>
                    </div>
                    <div class="row my-1 border-bottom">
                        <div class="col-md-3 font-weight-bold">Phone Number</div>
                        <div class="col-md-8">+880<?php echo e($value->phone_number); ?></div>
                    </div>
                      <div class="row my-1  border-bottom">
                        <div class="col-md-3 font-weight-bold">Police Station</div>
                        <div class="col-md-8"><?php echo e($value->policeStationName); ?></div>
                    </div>
                   
                    <div class="row my-1 border-bottom">
                        <div class="col-md-3 font-weight-bold">Employee Id</div>
                        <div class="col-md-8"><?php echo e($value->employee_id); ?></div>
                    </div>
                    <div class="row my-1 border-bottom">
                        <div class="col-md-3 font-weight-bold">Date of Birth</div>
                        <div class="col-md-8"><?php echo e($value->birth_day); ?></div>
                    </div>

                    <div class="row my-1 border-bottom">
                        <div class="col-md-3 font-weight-bold">Address</div>
                        <div class="col-md-8"><?php echo e($value->address); ?></div>
                    </div>
                    <div class="row my-1 border-bottom">
                        <div class="col-md-3 font-weight-bold">Usre Type</div>
                        <div class="col-md-8"><span class="badge badge-<?php echo e($value->address == 1 ? 'primary' : 'info'); ?>"><?php echo e($value->address == 1 ? 'Admin': 'User'); ?></span></div>
                    </div>
                    <div class="row my-1 border-bottom">
                        <div class="col-md-3 font-weight-bold">Email</div>
                        <div class="col-md-8"><?php echo e($value->address); ?></div>
                    </div>
                    <div class="row my-1">
                        <div class="col-md-3 font-weight-bold">Description</div>
                        <div class="col-md-8"><?php echo e($value->desc); ?></div>
                    </div>
                    
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div> <!-- end col-->
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crimeAdmin\resources\views/pages/profile/profile.blade.php ENDPATH**/ ?>