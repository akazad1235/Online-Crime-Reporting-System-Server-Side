

<?php $__env->startSection('content'); ?>

<div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title font-weight-bold">Add Police Station</h4>
                    <p class="sub-header">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <?php if(Session::has('added_recorded')): ?>
                            <script>
                                toastr.success("<?php echo Session::get('added_recorded'); ?>");
                            </script>
                        <?php endif; ?>
                         <?php if(Session::has('error_recorded')): ?>
                            <script>
                                toastr.error("<?php echo Session::get('error_recorded'); ?>");
                            </script>
                        <?php endif; ?>
                    </p>

                    <div class="row">
                        <div class="col-lg-12">
                            <form action="<?php echo e(route('station.store')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group mb-3">
                                    <label for="simpleinput">Station Name<apan class="text-danger">*</apan></label>
                                    <input type="text" id="simpleinput" class="form-control" name="policeStationName" placeholder="Enter Police Station Name" require>
                                </div>

                                <div class="form-group mb-3">
                                    <label for="example-email">Email<apan class="text-danger">*</apan></label>
                                    <input type="email" id="example-email" name="email" class="form-control" placeholder="Email" require>
                                </div>
                                <div class="form-group mb-3">
                                    <label for="dest">District<apan class="text-danger">*</apan></label>
                                    <select class="selectpicker" data-live-search="true" name="district"  data-style="btn-light">
                                            <option>Select District</option>
                                            <?php $__currentLoopData = $district; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($value->id); ?>"><?php echo e($value->district); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group mb-3">
                                    <label for="example-textarea">Address<apan class="text-danger">*</apan></label>
                                    <textarea class="form-control" id="example-textarea" rows="5" name="address" placeholder="Enter Police Stattion Adderess"></textarea>
                                </div>
                                <div class="form-group mb-3">
                                    <label for="example-textarea"></label>
                                    <input type="submit"  class=" btn btn-danger"  value="submit">
                                </div>
                            </form>
                        </div> <!-- end col -->
                    </div>
                    <!-- end row-->

                </div> <!-- end card-body -->
            </div> <!-- end card -->
        </div><!-- end col -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crimeAdmin\resources\views/pages/policeStation/addStation.blade.php ENDPATH**/ ?>