

<?php $__env->startSection('content'); ?>

<div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title font-weight-bold"> Police Station</h4>
                    <p class="sub-header">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <?php if(Session::has('added_recorded')): ?>
                            <script>
                                toastr.success("<?php echo Session::get('added_recorded'); ?>");
                            </script>
                        <?php endif; ?>
                         <?php if(Session::has('error_recorded')): ?>
                            <sc></sc>ript>
                                toastr.error("<?php echo Session::get('error_recorded'); ?>");
                            </script>
                        <?php endif; ?>
                    </p>

                    <div class="row">
                        <div class="col-lg-12">
                            <form action="<?php echo e(route('station.update', base64_encode($getDataById->id))); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group mb-3">
                                    <label for="simpleinput">Station Name<apan class="text-danger">*</apan></label>
                                    <input type="text" id="simpleinput" class="form-control" name="policeStationName" value="<?php echo e($getDataById->policeStationName); ?>" require>
                                </div>

                                <div class="form-group mb-3">
                                    <label for="example-email">Email<apan class="text-danger">*</apan></label>
                                    <input type="email" id="example-email" name="email" class="form-control" value="<?php echo e($getDataById->email); ?>" require>
                                </div>
                                <div class="form-group mb-3">
                                    <label for="example-textarea">Address<apan class="text-danger">*</apan></label>
                                    <textarea class="form-control" id="example-textarea" rows="5" name="address"><?php echo e($getDataById->address); ?></textarea>
                                </div>
                                <div class="form-group mb-3">
                                    <label for="example-textarea"></label>
                                    <input type="submit"  class=" btn btn-danger"  value="Update">
                                </div>
                            </form>
                        </div> <!-- end col -->
                    </div>
                    <!-- end row-->

                </div> <!-- end card-body -->
            </div> <!-- end card -->
        </div><!-- end col -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crimeAdmin\resources\views/pages/policeStation/editStation.blade.php ENDPATH**/ ?>