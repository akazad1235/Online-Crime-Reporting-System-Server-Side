

<?php $__env->startSection('content'); ?>

<div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title font-weight-bold">Add Criminals</h4>
                    <p class="sub-header">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <?php if(Session::has('added_recorded')): ?>
                            <script>
                                toastr.success("<?php echo Session::get('added_recorded'); ?>");
                            </script>
                        <?php endif; ?>
                         <?php if(Session::has('error_recorded')): ?>
                            <sc></sc>ript>
                                toastr.error("<?php echo Session::get('error_recorded'); ?>");
                            </script>
                        <?php endif; ?>
                    </p>

                    <div class="row">
                        <div class="col-lg-12">
                            <form action="<?php echo e(route('criminals.store')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group mb-3">
                                    <label for="simpleinput">Name<apan class="text-danger">*</apan></label>
                                    <input type="text" id="simpleinput" class="form-control" name="name" placeholder="Criminals Name" required />
                                </div>
                                <div class="form-group mb-3">
                                    
                                    <label for="example-email">Image<apan class="text-danger">*</apan></label>
                                    <input type="file" id="example-email" name="image" class="form-control" onChange="loadFile(event)"/>
                                    <img id="output" style="width:200px; height:200px; margin:3px" />
                    
                                </div>

                                <div class="form-group mb-3">
                                    <label for="example-textarea">desc<apan class="text-danger">*</apan></label>
                                    <textarea class="form-control" id="example-textarea" rows="5" name="desc" rows="5" name="address" placeholder="Criminals Description"></textarea>
                                </div>
                                <div class="form-group mb-3">
                                    <label for="example-textarea"></label>
                                    <input type="submit"  class=" btn btn-danger"  value="submit">
                                </div>
                            </form>
                        </div> <!-- end col -->
                    </div>
                    <!-- end row-->

                </div> <!-- end card-body -->
            </div> <!-- end card -->
        </div><!-- end col -->
    </div>
    <script>

        const loadFile = (event) => {
           let file = document.getElementById('output');
           file.src = URL.createObjectURL(event.target.files[0]);
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crimeAdmin\resources\views/pages/criminals/addCriminals.blade.php ENDPATH**/ ?>